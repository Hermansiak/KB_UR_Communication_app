package moduly;

public class ParserException extends Exception {

	public ParserException(String MessageToPrint)
	{
		super(MessageToPrint);
	}
}
