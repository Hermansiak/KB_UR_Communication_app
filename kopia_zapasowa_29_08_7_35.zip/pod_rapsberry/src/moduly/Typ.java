package moduly;

public enum Typ {
MOD_NAP_6W,
MOD_PRAD_2W,
MOD_PRZEKAZ_6;
	
}
